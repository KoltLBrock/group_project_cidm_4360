﻿using System;
using System.Collections.Generic;

namespace skelecode
{
    class Program
    {
        static void Main(string[] args)
        {
            int numPlayers = 2;


        }
    }
    class Deck{
        //array below will contain 52 strings, being the names of the cards
        private string[] STARTINGDECK = new string[]{"Ace of Spades","Ace of Hearts","Ace of Clubs","Ace of Diamonds","2 of Spades","2 of Hearts","2 of Clubs","2 of Diamonds"};

    }
    class Player{
        private List<string> playerDeck = new List<string>();
        public Player(){
            
        }
        public void addCard(string card){
            playerDeck.Add(card);
        }
    }
}